package org.ulpgc.is1.control;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}