package org.ulpgc.is1.model;

public class Item {

    private int quantitly;

    public Item(int quantitly){
        this.quantitly = quantitly;
    }

    public int getQuantitly() {
        return quantitly;
    }

    public void setQuantitly(int quantitly) {
        this.quantitly = quantitly;
    }
}
